'use strict';

module.exports = function noop () {};
