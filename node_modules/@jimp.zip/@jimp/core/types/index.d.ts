export * from './etc';
export * from './functions';
export * from './plugins';
export * from './utils';
import {Jimp, JimpConstructors} from './jimp';

export { Jimp, JimpConstructors };
declare const defaultExp: Jimp;
export default defaultExp;
